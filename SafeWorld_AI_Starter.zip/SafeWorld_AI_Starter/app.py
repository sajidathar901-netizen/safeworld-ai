from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import Literal
import re

app = FastAPI(title="SafeWorld AI", version="0.1.0")

class CheckRequest(BaseModel):
    text: str = Field(min_length=3, max_length=8000)
    mode: Literal["message", "job", "website"] = "message"

def analyze_rules(text: str, mode: str):
    t = text.lower()
    findings = []

    rules = [
        (r"pay (?:a )?(?:small )?(?:fee|charge)|processing fee|advance fee|registration fee|پہلے فیس|رجسٹریشن فیس|پروسیسنگ فیس",
         "Advance payment request", "High",
         "کسی انعام، نوکری یا رقم کے بدلے پہلے فیس مانگنا خطرے کی علامت ہو سکتا ہے۔"),
        (r"guaranteed (?:profit|return)|double your money|100% profit|guaranteed income|guaranteed job|پکا منافع|گارنٹیڈ منافع",
         "Unrealistic guarantee", "High",
         "یقینی منافع یا گارنٹیڈ آمدنی کے دعوے کو آزاد ذرائع سے اچھی طرح چیک کریں۔"),
        (r"you (?:have )?won|congratulations.*(?:prize|winner)|claim your prize|آپ جیت گئے|انعام حاصل کریں",
         "Unexpected prize claim", "High",
         "ایسے انعام سے محتاط رہیں جس میں آپ نے حصہ ہی نہ لیا ہو یا پہلے ادائیگی مانگی جائے۔"),
        (r"urgent|immediately|within 24 hours|act now|فوراً|جلدی کریں|آخری موقع",
         "Pressure or urgency", "Medium",
         "جلدی فیصلہ کروانے کا دباؤ دھوکے میں استعمال ہو سکتا ہے۔"),
        (r"password|otp|one.time password|verification code|پاس ورڈ|او ٹی پی|تصدیقی کوڈ",
         "Sensitive information request", "High",
         "اپنا پاس ورڈ، OTP یا تصدیقی کوڈ کسی کو نہ دیں۔"),
        (r"crypto|bitcoin|forex|investment plan|trading signal|کرپٹو|بٹ کوائن|سرمایہ کاری",
         "Financial/investment claim", "Medium",
         "سرمایہ کاری کے دعووں کو مستند اور آزاد ذرائع سے verify کریں؛ نقصان کا خطرہ ہوتا ہے۔"),
        (r"job offer|work from home|daily earning|recruitment fee|hiring fee|گھر بیٹھے کمائیں|روزانہ کمائی|نوکری",
         "Job or earning offer", "Medium",
         "کمپنی کی اصل ویب سائٹ اور رابطہ خود تلاش کر کے تصدیق کریں؛ نوکری کے لیے پیشگی فیس مشکوک ہو سکتی ہے۔"),
    ]

    for pattern, title, level, advice in rules:
        if re.search(pattern, t):
            findings.append({"title": title, "level": level, "advice": advice})

    if mode == "website":
        urls = re.findall(r"https?://[^\s]+|www\.[^\s]+", text, re.I)
        for url in urls:
            clean = url.lower()
            if re.search(r"bit\.ly|tinyurl|t\.co|goo\.gl|is\.gd", clean):
                findings.append({
                    "title": "Shortened link",
                    "level": "Medium",
                    "advice": "مختصر لنک اصل ویب سائٹ چھپا سکتا ہے۔ کھولنے سے پہلے اصل domain کی تصدیق کریں۔"
                })
            if re.search(r"xn--|@|[0-9]{4,}", clean):
                findings.append({
                    "title": "Unusual URL pattern",
                    "level": "Medium",
                    "advice": "ڈومین میں غیر معمولی حروف یا نمبرز نظر آ رہے ہیں؛ spelling خود چیک کریں۔"
                })

    if not findings:
        findings.append({
            "title": "No obvious pattern found",
            "level": "Unknown",
            "advice": "اس کا مطلب یہ نہیں کہ پیغام محفوظ ہے۔ بھیجنے والے، ویب سائٹ اور پیشکش کو الگ سے verify کریں۔"
        })

    levels = [x["level"] for x in findings]
    risk = "High" if "High" in levels else ("Medium" if "Medium" in levels else "Unclear")
    return {
        "risk": risk,
        "findings": findings,
        "disclaimer": "یہ ابتدائی خودکار جانچ ہے، حتمی فیصلہ نہیں۔ کسی لنک یا پیغام کو 100% محفوظ قرار نہیں دیا جا سکتا۔"
    }

@app.get("/")
def home():
    return FileResponse("static/index.html")

@app.post("/api/analyze")
def analyze(req: CheckRequest):
    return analyze_rules(req.text, req.mode)

app.mount("/static", StaticFiles(directory="static"), name="static")
