SafeWorld AI — Starter Project
================================

یہ ایک ابتدائی Web App/PWA starter ہے۔ اسے فون اور کمپیوٹر کے browser میں چلایا جا سکتا ہے۔

اہم حقیقت:
- موجودہ ورژن میں بنیادی rule-based scam indicators ہیں؛ یہ حقیقی AI model یا live fraud database نہیں۔
- AI کو فعال کرنے کے لیے server-side AI provider اور API key درکار ہوگی۔
- API key کبھی HTML/JavaScript میں نہ ڈالیں، اور کسی کے ساتھ password/OTP شیئر نہ کریں۔
- چونکہ API/hosting/payment اکاؤنٹس میں عمر اور ادائیگی کے تقاضے ہو سکتے ہیں، والدین/سرپرست کی مدد سے کام کریں۔
- کوئی checker کسی لنک یا پیغام کو 100% محفوظ قرار نہیں دے سکتا۔

چلانے کا آسان طریقہ:
1) Python 3.10+ انسٹال ہو۔
2) Terminal/Command Prompt میں اس فولڈر میں جائیں۔
3) چلائیں: pip install -r requirements.txt
4) چلائیں: uvicorn app:app --reload
5) Browser میں کھولیں: http://127.0.0.1:8000

اگلا مرحلہ:
- server پر محفوظ AI provider integration
- HTTPS hosting
- privacy policy اور data-retention rules
- Android app packaging
- ادائیگیوں کا نظام صرف قانونی/اکاؤنٹ اہلیت کی تصدیق اور سرپرست کی مدد کے بعد
